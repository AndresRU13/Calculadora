package bean;

import javax.ejb.Stateless;

/**
 *
 * @author Usuario
 */
@Stateless
public class CalcBean implements CalcBeanLocal {

    @Override
    public Integer Sumar(int a, int b) {
        return (a + b);
    }

    @Override
    public Integer Resta(int a, int b) {
        return (a - b);
    }

    @Override
    public Integer Multiplica(int a, int b) {
        return (a * b);
    }

    @Override
    public Integer Divide(int a, int b) {
        return (a / b);
    }

    @Override
    public Integer Modulo(int a, int b) {
        return (a % b);
    }

    @Override
    public Integer Cuadrado(int a) {
        return (a * a);
    }
    
    
}
